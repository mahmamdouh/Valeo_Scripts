cd C:\\DIA_SW\\SW\\DAI_M1_SYS_Software
git pull --rebase
git logreview --name-only --decorate  DAI-M1_SYS-22C.D01012029-0001-20220503..HEAD  >C:\\Users\\melmohta\\Desktop\\Integrator_Role\\Scripts\\Transfer_Plan_Script\\Vsersion_2\\SubFiles\\log.txt