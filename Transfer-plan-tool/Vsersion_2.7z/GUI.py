
#from PyQt5 import uic
#from PyQt5.QtWidgets import QApplication
from PyQt5.QtWidgets  import *
#from PyQt5.QtGui  import *
from PyQt5.uic  import  loadUi
from PyQt5.QtCore import QObject, QThread, pyqtSignal , QRunnable, Qt, QThreadPool ,QMutex
from PyQt5 import QtCore, QtGui
#from PyQt5.QtGui import QMovie
from PyQt5.QtGui import *
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import QLineEdit, QMessageBox, QFileDialog
#from matplotlib.backends.backend_qt5agg  import  ( NavigationToolbar2QT  as  NavigationToolbar )
#import  numpy  as  np
#import  random
#import pandas as pd
import sys
import os
from Integration1 import Runnable_1
from Functional_Lib import*
from datetime import datetime
from SystemFunction_SWC_Report import *
import time
#polarion_object = c.Polarion("https://vseapolarion.vnet.valeo.com/polarion/")



###############################################################################
###################### global variables #######################################

Version={
    "Version": "Version : 2.1.0",
}

Input_Data ={
    "Project":"VW_MEB_Inverter" ,
    "User name": " ",
    "Password": " ",
    "Int_Plan_Doc": " ",
    "Polarion_SW_Plan": " ",
    "RB": "" ,
    "L_Repo": "",
    "Directory": ",",
    "Report_Name": "",
}




Task={
    "Name": "...",
    "Progress": 0,
}

Script={
    "SWREQ_SWC_Bi_Directional": 0,
    "Release_WI": 0,
    "SF_status": 0,
    "SWA_SWREQ_Consistency": 0,
    "Delta_Report": 0,

}

Release_WI={
    "Status": " ",
}

Task_complete_valididty= {
    "Task_1": "..",
    "Task_2": "..",
    "Task_3": "..",
    "Task_4": "..",
    "Task_5": "..",
}

Task_Ignition= {
    "Task_1" :0 ,
    "Task_2" :0 ,
    "Task_3" :0 ,
    "Task_4" :0 ,
    "Task_5": 0,
}

Delta_Message={
    "Messsage" :"Skip this missage by select NO !" ,
    "Question" :"0" ,
    "Flag" :0 ,
    "Window" :0 ,
    "Update_Flag" :0 ,
}

Warning_Message ={
    "Warning" : "" ,
}


#########################################################################################
######################### initialization ###############################################
current_directory = os.getcwd()
final_directory = os.path.join(current_directory, r'Outputs')
if not os.path.exists(final_directory):
   os.makedirs(final_directory)

Directory = current_directory.replace("\\", "\\\\")





#########################################################################################
# 1. Subclass QRunnable
class Runnable(QRunnable):
    def __init__(self, n):
        super().__init__()
        self.n = n


    def run(self):
        print("Step 1")
        Input_Data["Report_Name"]= Create_Out_Report()
        print("Step 2")
        Prepare_Shell_Script(Input_Data)
        print("Step 3")
        os.system("Get_Repo.sh")
        print("Step 4")
        #print(Input_Data["Report_Name"])
        Runnable_1(Input_Data)
        print("Step 5")
        pass
'''
    def SF_Status(self):
        infoList = []
        infoList.append(Input_Data["User name"])
        infoList.append(Input_Data["Password"])
        infoList.append(Input_Data["Project"])
        infoList.append(Input_Data["Release_Document"])

        output_path = create_output_directory()

        folder_content = get_folder_data(infoList)

        output_workbook = Create_Report(output_path, infoList)

        docs_content = SF_get_work_items_ids(folder_content, infoList, output_workbook)

        SF_Array = prepare_SF_array(folder_content, docs_content)

        docs_content_detail, SF_Array, workbook, worksheet3 = get_work_items_Details_data(docs_content, infoList,
                                                                                          SF_Array, output_workbook)
        SWC_SF_Array_Mapp = Separaate_SWC_SF(SF_Array)
        Write_SWC_VS_SF_Report(SWC_SF_Array_Mapp, workbook, worksheet3)
'''



class MatplotlibWidget(QMainWindow):

    def __init__(self):
        ##print("clicked in init")
        QMainWindow.__init__(self)

        loadUi("Main_Window.ui", self)
        self.show()
        self.UiTimer()
        self.setWindowTitle("SWA Release Tool")


        # tool Bar
        toolbar = QToolBar("Menue tools")
        self.addToolBar(toolbar)
        button_action = QAction("About", self)
        button_action.setStatusTip("About Tool")
        button_action.triggered.connect(self.onMyToolBarButtonClick)
        toolbar.addAction(button_action)
        toolbar2 = QToolBar("Menue tools")

        self.addToolBar(toolbar2)
        button_action2 = QAction("Help", self)
        button_action2.setStatusTip("How to Use tool?")
        button_action2.triggered.connect(self.Help_Menue)
        toolbar2.addAction(button_action2)

        self.browse.clicked.connect(self.Get_Directory)


        self.P_Pass.setEchoMode(10)
        self.progressBar.setValue(0)
        self.Version.setText(Version["Version"])
        self.P_Project.currentIndexChanged.connect(self.Select_Proj)

        #self.About.clicked.connect(self.onMyToolBarButtonClick)

        self.Run.clicked.connect(self.Script_Runnable)

    def Help_Menue(self):
        Help_path = os.getcwd()
        file_path = Help_path + "\Help.html"
        os.startfile(file_path)

    def onMyToolBarButtonClick(self):
        self.Setting1.show()

    def UiTimer(self):
        # variables
        # count variable
        self.count = 0
        # start flag
        self.start = False
        # creating a timer object
        self.timer = QtCore.QTimer(self)
        # adding action to timer
        self.timer.timeout.connect(self.update_graph)
        # update the timer every tenth second
        self.timer.start(3000)

    def runTasks(self):
        threadCount = QThreadPool.globalInstance().maxThreadCount()
        #self.label.setText(f"Running {threadCount} Threads")
        pool = QThreadPool.globalInstance()
        runnable = Runnable(1)
        # 3. Call start()
        pool.start(runnable)

    def update_graph(self):
        #self.Define_Script_To_Run()
        #self.Mandatory_Flags_Updtor()

        self.label_10.setText(Task["Name"])
        self.progressBar.setValue(Task["Progress"])


    def Select_Proj(self):
        Current_Proj= " "
        ##print("Change happened")
        Current_Cam_Section_Name = str(self.P_Project.currentText())
        ##print(Current_Cam_Section_Name)

        if Current_Cam_Section_Name == "VW_MEB_Inverter" :
            Current_Proj="VW_MEB_Inverter"
        elif Current_Cam_Section_Name == "BMW" :
            Current_Proj="obc_35up11kw"
        elif Current_Cam_Section_Name == "PSA":
            Current_Proj="phev_psa_erad_gen2"
        elif Current_Cam_Section_Name == "CEVT":
            Current_Proj="mma_cm1e_dcdc"
        elif Current_Cam_Section_Name == "100-KW":
            Current_Proj="optimus"
        elif Current_Cam_Section_Name == "model_kit":
            Current_Proj="model_kit"
        elif Current_Cam_Section_Name == "DAI":
            Current_Proj="S_DAI_SYS"
        Input_Data["Project"] = Current_Proj

    def Get_Input(self):
        self.Select_Proj()
        infoList = []
        Input_Data["User name"]=self.P_User.text()
        Input_Data["Password"] =self.P_Pass.text()
        #Input_Data["Project"] = str(self.P_Project.currentText())
        Input_Data["Int_Plan_Doc"] =self.Int_Plan_Document.text()
        Input_Data["Polarion_SW_Plan"] =self.Polarion_Plan.text()
        Input_Data["RB"] =self.Start_RB.text()
        Input_Data["L_Repo"] = self.L_Repo.text()
        Input_Data["Directory"] = Directory

        #Input_Data["SWCompPlan"] = Input_Data["Release_Document"]



    def Get_Directory(self):
        self.dir_path = QFileDialog.getExistingDirectory(self, "Choose Directory", "E:\\")
        print(self.dir_path)
        self.L_Repo.setText(self.dir_path)
        Input_Data["L_Repo"] = self.L_Repo.text()
        print(self.L_Repo.text())

    def Script_Runnable(self):
        self.Get_Input()
        self.runTasks()


class About(QMainWindow):
    def __init__(self):
        super(About, self).__init__()
        loadUi("About.ui", self)
        self.label_10.setText(Version["Version"])

        # variable
        # Button





if __name__ == '__main__':
    app = QApplication([])
    window  =  MatplotlibWidget ()
    sys.exit(app.exec())

