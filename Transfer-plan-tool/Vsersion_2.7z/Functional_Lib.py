import xlsxwriter


def Prepare_Shell_Script(Input_Data):
    print("Start of generating file ...")
    print("Input Data :",Input_Data)
    file1 = open("Get_Repo.sh", "w")
    local_repo = Input_Data["L_Repo"].replace("/", "\\\\")
    L = ["cd " + local_repo, "\ngit pull --rebase", "\ngit logreview --name-only --decorate  " + Input_Data[
        "RB"] + "..HEAD  >"+Input_Data["Directory"]+"\\\\SubFiles\\\\log.txt"]
    file1.writelines(L)
    file1.close()



def Create_Out_Report():
    print("Create")
    File_Name = "Outputs\Integration_Report.xlsx"
    output_workbook = File_Name
    workbook1 = xlsxwriter.Workbook(output_workbook)

    # Create Excel document

    Sheet1 = workbook1.add_worksheet('Sheet1')


    format1 = workbook1.add_format({'bg_color': '#c7f1ff',
                                   'font_color': '#9C0006'})
    format1.set_bold()

    Sheet1.write("A1", "commit", format1)
    Sheet1.write("B1", "Author", format1)
    Sheet1.write("C1", "Change ID", format1)
    Sheet1.write("D1", "Tag", format1)
    Sheet1.write("E1", "SWCs", format1)
    Sheet1.write("F1", "Functional affected SWCS", format1)
    Sheet1.write("G1", "Affected System Function", format1)
    print("Create 1")
    workbook1.close()
    print("Create 2")
    return "Outputs\Integration_Report.xlsx"


