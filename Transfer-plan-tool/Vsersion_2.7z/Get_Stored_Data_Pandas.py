import pandas as pd
import os
import xlsxwriter
from datetime import datetime
import os.path



def Get_Release_WIs(file1):
    Release1_Data={
     "SWA_Data": 0,
     "SWREQ_Data": 0,
    }
    # SW interface
    df = pd.read_excel(file1, 'Sheet1') # can also index sheet by name or fetch all sheets
    DataList= df['commit'].tolist()
    df= df.fillna(0)
    Data = df.to_dict()
    Release1_Data["SWA_Data"] = Data

    return Data


